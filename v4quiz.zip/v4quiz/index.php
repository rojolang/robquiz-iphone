<?php require_once($_SERVER['DOCUMENT_ROOT'].'/kowboykit/includes/money.php'); ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1"/>
    <link rel="preload" href="/v4quiz/_next/static/media/a34f9d1faa5f3315-s.p.woff2" as="font" crossorigin="" type="font/woff2"/>
    <link rel="preload" as="image" href="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/main-qimg-fe14c462c2025fcfe5a696fc2a64b2bb-3BNBEfS49IhI5iFTOjTLo5bcnT7nUv.webp"/>
    <link rel="stylesheet" href="/v4quiz/_next/static/css/55fa10382a7c2ccf.css" data-precedence="next"/>
    <link rel="preload" as="script" fetchPriority="low" href="/v4quiz/_next/static/chunks/webpack-d62b810a1ffcef32.js"/>
    <script src="/v4quiz/_next/static/chunks/0bd1736e-67c763f74e89a53b.js" async=""></script>
    <script src="/v4quiz/_next/static/chunks/14-a97bee5a5fb06e05.js" async=""></script>
    <script src="/v4quiz/_next/static/chunks/main-app-21e2c6006988d8fa.js" async=""></script>
    <script src="/v4quiz/_next/static/chunks/296-5af3a9885e99cfd7.js" async=""></script>
    <script src="/v4quiz/_next/static/chunks/app/page-54b621b25e014cf6.js" async=""></script>
    <script src="/v4quiz/_next/static/chunks/app/layout-f05b64cf01484a13.js" async=""></script>
    <title>RobChat2</title>
    <meta name="description" content="A chat application with Android-like UI"/>
    <link rel="icon" href="/favicon.ico" type="image/x-icon" sizes="16x16"/>
    <meta name="next-size-adjust"/>
    <script src="/v4quiz/_next/static/chunks/polyfills-78c92fac7aa8fdd8.js" noModule=""></script>
</head>
<body class="__className_36bd41">
<noscript>
    <iframe src="https://www.googletagmanager.com/ns.html?id=GTM-TZTF7T2R" height="0" width="0" style="display:none;visibility:hidden"></iframe>
</noscript>
<div id="phone-number-container" class="hidden">
    <a href="tel:+18666731626" id="click-to-call-button" class="bg-green-500 text-white font-bold py-2 px-4 rounded">Call Now: (866) 673-1626</a>
</div>
<main class="flex min-h-screen items-center justify-center bg-gray-100">
    <div class="w-[375px] h-[812px] overflow-hidden shadow-lg bg-white flex flex-col rounded-3xl border-8 border-gray-800 touch-manipulation">
        <div class="bg-black text-white text-xs p-1 rounded-t-2xl flex justify-between items-center">
            <span>11:21 PM</span>
            <div class="flex space-x-1 items-center">
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-wifi h-4 w-4">
                    <path d="M12 20h.01"></path>
                    <path d="M2 8.82a15 15 0 0 1 20 0"></path>
                    <path d="M5 12.859a10 10 0 0 1 14 0"></path>
                    <path d="M8.5 16.429a5 5 0 0 1 7 0"></path>
                </svg>
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-battery h-4 w-4">
                    <rect width="16" height="10" x="2" y="7" rx="2" ry="2"></rect>
                    <line x1="22" x2="22" y1="11" y2="13"></line>
                </svg>
            </div>
        </div>
        <div class="bg-blue-500 p-3 text-white flex items-center justify-between relative z-10">
            <div class="flex items-center">
                <div class="w-10 h-10 mr-3 border-2 border-white rounded-full overflow-hidden">
                    <img src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/main-qimg-fe14c462c2025fcfe5a696fc2a64b2bb-3BNBEfS49IhI5iFTOjTLo5bcnT7nUv.webp" alt="Emily" class="w-full h-full object-cover"/>
                </div>
                <div>
                    <div class="font-semibold text-lg">Emily</div>
                    <div class="text-xs flex items-center">
                        <span class="w-2 h-2 bg-green-400 rounded-full mr-1"></span>
                        <span>Online</span>
                    </div>
                </div>
            </div>
            <div class="flex items-center">
                <a href="tel:+18666731626" class="text-sm mr-2 hover:underline flex items-center">
                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-phone w-4 h-4 mr-1">
                        <path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"></path>
                    </svg>
                    <span class="text-base">(866) 673-1626</span>
                </a>
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-ellipsis-vertical w-5 h-5">
                    <circle cx="12" cy="12" r="1"></circle>
                    <circle cx="12" cy="5" r="1"></circle>
                    <circle cx="12" cy="19" r="1"></circle>
                </svg>
            </div>
        </div>
        <div class="flex-1 overflow-hidden">
            <div class="flex flex-col h-full bg-gray-100">
                <div class="flex-1 overflow-y-auto px-3 py-4"></div>
                <div class="bg-white p-2">
                    <div class="flex items-center bg-gray-100 rounded-full p-2">
                        <button class="p-2 rounded-full bg-gray-200 mr-2">
                            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-mic w-5 h-5 text-gray-600">
                                <path d="M12 2a3 3 0 0 0-3 3v7a3 3 0 0 0 6 0V5a3 3 0 0 0-3-3Z"></path>
                                <path d="M19 10v2a7 7 0 0 1-14 0v-2"></path>
                                <line x1="12" x2="12" y1="19" y2="22"></line>
                            </svg>
                        </button>
                        <input type="text" placeholder="Type a message..." class="flex-1 bg-transparent outline-none text-sm" value=""/>
                        <button class="p-2 rounded-full bg-blue-500 ml-2">
                            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-send w-5 h-5 text-white">
                                <path d="m22 2-7 20-4-9-9-4Z"></path>
                                <path d="M22 2 11 13"></path>
                            </svg>
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </div>
</main>
<script src="/v4quiz/_next/static/chunks/webpack-d62b810a1ffcef32.js" async=""></script>
<script>
    document.getElementById('click-to-call-button').addEventListener('click', function() {
        var xhr = new XMLHttpRequest();
        xhr.open('GET', '<?= $link['step1link']; ?>', true);
        xhr.send();
    });
</script>
<script>(self.__next_f=self.__next_f||[]).push([0]);self.__next_f.push([2,null])</script>
<script>self.__next_f.push([1,"1:HL[\"/v4quiz/_next/static/media/a34f9d1faa5f3315-s.p.woff2\",\"font\",{\"crossOrigin\":\"\",\"type\":\"font/woff2\"}]\n2:HL[\"/v4quiz/_next/static/css/55fa10382a7c2ccf.css\",\"style\"]\n"])</script>
<script>self.__next_f.push([1,"3:I[4607,[],\"\"]\n5:I[4127,[],\"ClientPageRoot\"]\n6:I[2842,[\"296\",\"/v4quiz/_next/static/chunks/296-5af3a9885e99cfd7.js\",\"931\",\"/v4quiz/_next/static/chunks/app/page-54b621b25e014cf6.js\"],\"default\"]\n7:I[2044,[\"185\",\"/v4quiz/_next/static/chunks/app/layout-f05b64cf01484a13.js\"],\"\"]\n8:I[879,[],\"\"]\n9:I[8394,[],\"\"]\nb:I[4936,[],\"\"]\nc:[]\n"])</script>
<script>self.__next_f.push([1,"0:[[[\"$\",\"link\",\"0\",{\"rel\":\"stylesheet\",\"href\":\"/v4quiz/_next/static/css/55fa10382a7c2ccf.css\",\"precedence\":\"next\",\"crossOrigin\":\"$undefined\"}]],[\"$\",\"$L3\",null,{\"buildId\":\"z8W3RBfSh3uCCgsdwBZgC\",\"assetPrefix\":\"\",\"initialCanonicalUrl\":\"/\",\"initialTree\":[\"\",{\"children\":[\"__PAGE__\",{}]},\"$undefined\",\"$undefined\",true],\"initialSeedData\":[\"\",{\"children\":[\"__PAGE__\",{},[[\"$L4\",[\"$\",\"$L5\",null,{\"props\":{\"params\":{},\"searchParams\":{}},\"Component\":\"$6\"}]],null],null]},[[\"$\",\"html\",null,{\"lang\":\"en\",\"children\":[[\"$\",\"head\",null,{\"children\":[[\"$\",\"$L7\",null,{\"id\":\"google-tag-manager\",\"strategy\":\"afterInteractive\",\"children\":\"\\n                        (function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':\\n                        new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],\\n                        j=d.createElement(s),dl=l!='dataLayer'?'\u0026l='+l:'';j.async=true;j.src=\\n                        'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);\\n                        })(window,document,'script','dataLayer','GTM-TZTF7T2R');\\n                    \"}],[\"$\",\"title\",null,{}]]}],[\"$\",\"body\",null,{\"className\":\"__className_36bd41\",\"children\":[[\"$\",\"noscript\",null,{\"children\":[\"$\",\"iframe\",null,{\"src\":\"https://www.googletagmanager.com/ns.html?id=GTM-TZTF7T2R\",\"height\":\"0\",\"width\":\"0\",\"style\":{\"display\":\"none\",\"visibility\":\"hidden\"}}]}],[\"$\",\"div\",null,{\"id\":\"phone-number-container\",\"className\":\"hidden\",\"children\":[\"$\",\"a\",null,{\"href\":\"tel:+18666731626\",\"id\":\"click-to-call-button\",\"className\":\"bg-green-500 text-white font-bold py-2 px-4 rounded\",\"children\":\"Call Now: (866) 673-1626\"}]}],[\"$\",\"$L8\",null,{\"parallelRouterKey\":\"children\",\"segmentPath\":[\"children\"],\"error\":\"$undefined\",\"errorStyles\":\"$undefined\",\"errorScripts\":\"$undefined\",\"template\":[\"$\",\"$L9\",null,{}],\"templateStyles\":\"$undefined\",\"templateScripts\":\"$undefined\",\"notFound\":[[\"$\",\"title\",null,{\"children\":\"404: This page could not be found.\"}],[\"$\",\"div\",null,{\"style\":{\"fontFamily\":\"system-ui,\\\"Segoe UI\\\",Roboto,Helvetica,Arial,sans-serif,\\\"Apple Color Emoji\\\",\\\"Segoe UI Emoji\\\"\",\"height\":\"100vh\",\"textAlign\":\"center\",\"display\":\"flex\",\"flexDirection\":\"column\",\"alignItems\":\"center\",\"justifyContent\":\"center\"},\"children\":[\"$\",\"div\",null,{\"children\":[[\"$\",\"style\",null,{\"dangerouslySetInnerHTML\":{\"__html\":\"body{color:#000;background:#fff;margin:0}.next-error-h1{border-right:1px solid rgba(0,0,0,.3)}@media (prefers-color-scheme:dark){body{color:#fff;background:#000}.next-error-h1{border-right:1px solid rgba(255,255,255,.3)}}\"}}],[\"$\",\"h1\",null,{\"className\":\"next-error-h1\",\"style\":{\"display\":\"inline-block\",\"margin\":\"0 20px 0 0\",\"padding\":\"0 23px 0 0\",\"fontSize\":24,\"fontWeight\":500,\"verticalAlign\":\"top\",\"lineHeight\":\"49px\"},\"children\":\"404\"}],[\"$\",\"div\",null,{\"style\":{\"display\":\"inline-block\"},\"children\":[\"$\",\"h2\",null,{\"style\":{\"fontSize\":14,\"fontWeight\":400,\"lineHeight\":\"49px\",\"margin\":0},\"children\":\"This page could not be found.\"}]}]]}]}]],\"notFoundStyles\":[],\"styles\":null}]]}]]}],null],null],\"couldBeIntercepted\":false,\"initialHead\":[null,\"$La\"],\"globalErrorComponent\":\"$b\",\"missingSlots\":\"$Wc\"}]]\n"])</script>
<script>self.__next_f.push([1,"a:[[\"$\",\"meta\",\"0\",{\"name\":\"viewport\",\"content\":\"width=device-width, initial-scale=1\"}],[\"$\",\"meta\",\"1\",{\"charSet\":\"utf-8\"}],[\"$\",\"title\",\"2\",{\"children\":\"RobChat2\"}],[\"$\",\"meta\",\"3\",{\"name\":\"description\",\"content\":\"A chat application with Android-like UI\"}],[\"$\",\"link\",\"4\",{\"rel\":\"icon\",\"href\":\"/favicon.ico\",\"type\":\"image/x-icon\",\"sizes\":\"16x16\"}],[\"$\",\"meta\",\"5\",{\"name\":\"next-size-adjust\"}]]\n4:null\n"])</script>
</body>
</html>
